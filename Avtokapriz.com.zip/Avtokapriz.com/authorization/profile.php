<?php
	session_start();
	if (!$_SESSION['user']) {
		header('Location: authorization.php');
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Автозапчасти для иномарок">
	<meta name="keywords" content="Иномарки,запчасти, запчасти для иномарок,автозапчасти">
	<link rel="apple-touch-icon" sizes="57x57" href="../assets/img/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="../assets/img/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="../assets/img/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="../assets/img/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="../assets/img/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="../assets/img/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="../assets/img/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="../assets/img/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192"  href="../assets/img/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="../assets/img/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="../assets/img/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="../assets/img/favicon-16x16.png">
	<link rel="manifest" href="..//manifest.json">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
	<meta name="theme-color" content="#ffffff">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
	<link rel="stylesheet" href="../assets/css/profile.css">
	<script src="../admin/js/jquery-3.6.0.min.js"></script>
	<title>Document</title>
</head>
<body>
	<div class="container">
		<form>
			<br>
			<img src="<?= $_SESSION['user']['avatar'] ?>" width="200">
			<h2 style="margin:10px 0;" ><?= $_SESSION['user']['full_name'] ?></h2><br>
			<a href="#"><?= $_SESSION['user']['email'] ?></a><br><br>
			<a href="vendor/logout.php " class="logout-btn">Вихід</a><br><br>
			<a href="/" class="logout-btn">На головну</a>
		</form>
	</div>
</body>
</html>