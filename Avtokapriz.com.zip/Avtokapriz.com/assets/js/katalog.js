var cart = {};

$('document').ready(function(){
	$('#d0').on('click', function(){
		loadGoods(758631);
	});
	$('#d1').on('click', function(){
		loadGoods(1);
	});
	$('#d2').on('click', function(){
		loadGoods(2);
	});
	$('#d3').on('click', function(){
		loadGoods(3);
	});
	$('#d4').on('click', function(){
		loadGoods(4);
	});
	$('#d5').on('click', function(){
		loadGoods(5);
	});
	$('#d6').on('click', function(){
		loadGoods(6);
	});
	$('#d7').on('click', function(){
		loadGoods(7);
	});
	$('#d8').on('click', function(){
		loadGoods(8);
	});
	$('#d9').on('click', function(){
		loadGoods(9);
	});
	$('#d10').on('click', function(){
		loadGoods(10);
	});
	$('#d11').on('click', function(){
		loadGoods(11);
	});
	$('#d12').on('click', function(){
		loadGoods(12);
	});
	$('#d13').on('click', function(){
		loadGoods(13);
	});
	$('#d14').on('click', function(){
		loadGoods(14);
	});
	$('#d15').on('click', function(){
		loadGoods(15);
	});
	$('#d16').on('click', function(){
		loadGoods(16);
	});

	loadGoods(758631);
});

function loadGoods(ord) {
	$.getJSON('goods.json', function(data){
		console.log(data);
		var out = '';
		for (var key in data) {
			if (data[key].ord == ord) {
				out +='<div class="single-goods">';
				out +='<div class="cart">';
				out +=`<div class="cart-img-box"><img src="images/${data[key].img}" alt=""></div>`;
		        out +=`<div class="name">${data[key].name}</div>`;
		        out +=`<div class="description">Опис товару:<br> ${data[key].description}</div>`;
		        out +=`<div class="cost">Ціна: ${data[key].cost} грн</div>`;
		        out +=`<button class="add-to-cart" data-id="${key}"><i class="fas fa-shopping-cart"></i> Купити</button>`;
		        out +='</div>';
		        out +='</div>';
	        }else if (ord == 758631){
	        	out +='<div class="single-goods">';
				out +='<div class="cart">';
				out +=`<div class="cart-img-box"><img src="images/${data[key].img}" alt=""></div>`;
		        out +=`<div class="name">${data[key].name}</div>`;
		        out +=`<div class="description">Опис товару:<br> ${data[key].description}</div>`;
		        out +=`<div class="cost">Ціна: ${data[key].cost} грн</div>`;
		        out +=`<button class="add-to-cart" data-id="${key}"><i class="fas fa-shopping-cart"></i> Купити</button>`;
		        out +=`<button class="later" data-id="${key}"><i class="fas fa-heart"></i></button>`;
		        out +='</div>';
		        out +='</div>';
	        }
		}
		$('#goods').html(out);
		$('.add-to-cart').on('click', addToCart);
		$('.later').on('click', addToLater);
	});
};

function addToLater () {
	var later = {};
	if (localStorage.getItem('later')) {
		later = JSON.parse(localStorage.getItem('later'));
		showMiniCart();
	}
	alert ('Додано в Бажаня');
	var id = $(this).attr('data-id');
	later[id] = 1;
	localStorage.setItem('later',JSON.stringify(later));
}

function addToCart () {
	var id = $(this).attr('data-id');
	//console.log(id);
	if (cart[id]==undefined) {
		cart [id] = 1;
		alert ("Товар додано у кошик");
	}else {
		cart [id]++;
		alert ("Товар додано у кошик");
	}
	showMiniCart();
	saveCart();

}

function saveCart() {
	localStorage.setItem('cart',JSON.stringify(cart));
}

function showMiniCart() {
	var out = "";
	for (var key in cart) {
		out += key +' --- '+ cart[key]+'<br>';
	}
	$('.mini-cart').html(out);
}

function loadCart () {
	if (localStorage.getItem('cart')) {
		cart = JSON.parse(localStorage.getItem('cart'));
		showMiniCart();
	}
}
$(document).ready(function() {
	loadCart();
});