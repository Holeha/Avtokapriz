var cart = {};

$('document').ready(function(){
	loadGoods();
});

function loadGoods(ord) {
	$.getJSON('goods.json', function(data){
		console.log(data);
		var out = '';
		var later = {};
		if (localStorage.getItem('later')) {
			later = JSON.parse(localStorage.getItem('later'));
				for (var key in later) {
						out +='<div class="single-goods">';
						out +='<div class="cart">';
						out +=`<div class="cart-img-box"><img src="images/${data[key].img}" alt=""></div>`;
				        out +=`<div class="name">${data[key].name}</div>`;
				        out +=`<div class="description">Опис товару:<br> ${data[key].description}</div>`;
				        out +=`<div class="cost">Ціна: ${data[key].cost} грн</div>`;
				        out +=`<a href="goods.php#${key}">Переглянути</a>`;
				        out +='</div>';
				        out +='</div>';
				}
				$('#goods').html(out);
		}else {
			$('#goods').html('<h4>Додайте товар в Бажання!</h4>');
		}
	});
};

$(document).ready(function() {
	init ();
});