<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Автозапчасти для иномарок">
  <meta name="keywords" content="Иномарки,запчасти, запчасти для иномарок,автозапчасти">
  <link rel="apple-touch-icon" sizes="57x57" href="assets/img/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="assets/img/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="assets/img/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="assets/img/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="assets/img/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="assets/img/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="assets/img/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192"  href="assets/img/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png">
	<link rel="manifest" href="/manifest.json">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
	<meta name="theme-color" content="#ffffff">
  <link rel="stylesheet" href="assets/css/main.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Zen+Dots&display=swap" rel="stylesheet">
  <script src="https://kit.fontawesome.com/b8991598b2.js" ></script>
  <title>Питання</title>
</head>
<body>
<div class="main">
	<div class="fon-header">
	<div class="container">
		<div class="header">
			<div class="logo">
				<a href="index.php"><img src="assets/img/logo_passive.jpg"><a/>
					<div class="logo-text">
						<h1>Avtokapriz</h1>
						<h2>Виконаємо будь-який каприз Вашого автомобіля!</h2>
					</div>
			</div>

			<div class="info">
				<h2>вул. Заводська, 3о, Нова Каховка,<br> Херсонська область, 74900</h2>
			</div>

			<div class="search-box">
				<input type="text" class="search-txt" placeholder="Пошук по VIN">
					<a href="#" class="search-btn"><i class="fa fa-search" aria-hidden="true"></i></a>
			</div>	


				<?
				if ($_SESSION['user']) { ?> 
				<div class="cart-btn">
					<button onclick="document.location='cart.php'" type="button" class="btn btn-outline-danger"><i class="fas fa-shopping-cart"></i></button>
				</div>

				<div class="later-btn">
					<button onclick="document.location='later.php'" type="button" class="btn btn-outline-danger"><i class="fas fa-heart"></i></button>
				</div>

	         	<div class="enterance">
					<button onclick="document.location='authorization/profile.php'" type="button" class="btn btn-outline-danger"><i class="fas fa-user"></i> Профіль</button>
				</div>
				<? } else { ?>
				<div class="cart-btn">
					<button onclick="document.location='cart.php'" type="button" class="btn btn-outline-danger"><i class="fas fa-shopping-cart"></i></button>
				</div>
				
	         	<div class="enterance">
					<button onclick="document.location='authorization/authorization.php'" type="button" class="btn btn-outline-danger"><i class="fas fa-sign-in-alt"></i> Вхід | Реєстрація</button>
				</div>
				<? } ?>

		</div>
	</div>
	</div>

	<div class="fon-slider">
	<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
  		<div class="carousel-indicators">
    		<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    		<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    		<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
    		<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>
  		</div>
		<div class="carousel-inner">
		    <div class="carousel-item active">
		      	<img src="assets/img/picture1.jpg" class="d-block w-100" alt="...">
		      	<div class="carousel-caption d-none d-md-block">
		        	<h5></h5>
		        	<p></p>
		      	</div>
		    </div>
		    <div class="carousel-item">
		      	<img src="assets/img/picture2.jpg" class="d-block w-100" alt="...">
		      	<div class="carousel-caption d-none d-md-block">
		        	<h5></h5>
		        	<p></p>
		      	</div>
		    </div>
		    <div class="carousel-item">
		      	<img src="assets/img/picture3.jpg" class="d-block w-100" alt="...">
		      	<div class="carousel-caption d-none d-md-block">
		        	<h5></h5>
		        	<p></p>
		      	</div>
		    </div>
		    <div class="carousel-item">
		      	<img src="assets/img/picture4.jpg" class="d-block w-100" alt="...">
		      	<div class="carousel-caption d-none d-md-block">
		        	<h5></h5>
		        	<p></p>
		      	</div>
		    </div>
	    </div>

		<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"  data-bs-slide="prev">
		  	<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		    <span class="visually-hidden">Попередній</span>
		</button>
		<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"  data-bs-slide="next">
		    <span class="carousel-control-next-icon" aria-hidden="true"></span>
		    <span class="visually-hidden">Наступний</span>
		</button>
	</div>
	</div>


	<div class="nav-bar">
		<div class="container">
			<div class="menu">
				<nav class="dws-menu">
				    <ul>
				      <li><a href="index.php"><i class="fa fa-home"></i>Головна</a></li>
				      <li><a href="katalog.php"><i class="fa fa-shopping-cart"></i>Каталог</a></li>
				      <li><a href="news.php"><i class="fa fa-newspaper"></i>Новини</a></li>
				      <li><a href="delivery.php"><i class="fa fa-truck-loading"></i>Доставкa</a></li>
				      <li><a href="payments.php"><i class="fa fa-money-bill-alt"></i>Оплата</a></li>
				      <li><a href="kontakts.php"><i class="fa fa-envelope-open"></i>Контакти</a></li>
				      <li><a href="ask.php"><i class="fa fa-question-circle"></i>Питання</a></li>
				      <li><a href="comments.php"><i class="fa fa-comments"></i>Відгуки</a></li>
				    </ul>
				</nav>
			</div>
		</div>
	</div>

	<form action="assets/php/telegram.php" method="POST">
	<div class="ask">
		<h2 class="mainText">Залиште заявку</h2>
		<p class="secondText">І ми зв'яжемося з вами!</p>
		<div class="askInput">
			<span><i class="fas fa-user"></i></span>
			<input type="text" name="ask_username" placeholder="Введіть ваше ім'я">
		</div>
		<div class="askInput">
			<span><i class="fas fa-phone-alt"></i></span>
			<input type="text" name="ask_userphone" placeholder="Введіть ваш телефон">
		</div>
		<div class="askInput">
			<span><i class="fas fa-envelope-open"></i></span>
			<input type="text" name="ask_usermail" placeholder="Введіть ваш E-Mail">
		</div>
		<input type="submit" class="send" value="Надіслати">
	</div>
	</form>

	<footer class="footer">
	  	<div class="container">
	  	 	<div class="footer-columns">
	  	 		<div class="footer-col">
	  	 			<h4>Клієнтам</h4>
	  	 			<ul>
	  	 				<li><a href="#">Як знайти деталь</a></li>
	  	 				<li><a href="#">Як зробити замовлення</a></li>
	  	 				<li><a href="payments.php">Оплата</a></li>
	  	 				<li><a href="delivery.php">Доставка</a></li>
	  	 				<li><a href="ask.php">Зворотній зв'язок</a></li>
	  	 			</ul>
	  	 		</div>
	  	 		<div class="footer-col">
	  	 			<h4>Информація</h4>
	  	 			<ul>
	  	 				<li><a href="kontakts.php">Контакти</a></li>
	  	 				<li><a href="news.php">Новини</a></li>
	  	 				<li><a href="ask.php">Питання-відповідь</a></li>
	  	 				<li><a href="comments.php">Відгуки</a></li>
	  	 			</ul>
	  	 		</div>
	  	 		<div class="footer-col">
	  	 			<h4>Каталог товарів</h4>
	  	 			<ul>
	  	 				<li><a href="#">Запчастини ТО</a></li>
	  	 				<li><a href="#">Шини та диски</a></li>
	  	 				<li><a href="#">Масла</a></li>
	  	 				<li><a href="#">Аксесуари</a></li>
	  	 				<li><a href="#">Автоскло</a></li>
	  	 				<li><a href="#">Акумулятори</a></li>
	  	 			</ul>
	  	 		</div>
	  	 		<div class="footer-col">
	  	 			<h4>Ми в соц мережах</h4>
	  	 			<div class="social-links">
	  	 				<a href="#"><i class="fab fa-facebook-f"></i></a>
	  	 				<a href="#"><i class="fab fa-twitter"></i></a>
	  	 				<a href="#"><i class="fab fa-instagram"></i></a>
	  	 				<a href="#"><i class="fab fa-linkedin-in"></i></a>
	  	 			</div>
	  	 		</div>
	  	 	</div>
	  	</div>
  	</footer>

	<div class="underfooter">
		<div class="container">
			<p class="company">© 2021, ООО "Компанія «Автокапріз»"</p>
		</div>
	</div>

</div>
</body>
</html>